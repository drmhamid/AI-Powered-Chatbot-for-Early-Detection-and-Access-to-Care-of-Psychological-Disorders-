def MFS(n, l):
    for num in range(n, l + 1):
        output = ""

        if num % 3 == 0:
            output += "Food "
        if num % 5 == 0:
            output += "is our "
        if num % 4 == 0:
            output += "common "
        if num % 8 == 0:
            output += "ground "

        if output == "":
            output = "Food is our common ground"

        print(output)


# Sample Input
MFS(0, 8)
